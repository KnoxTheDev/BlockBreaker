from mcstatus import JavaServer

def ping_command(args):
    """Pings the Minecraft server at the given IP and port using mcstatus."""
    if len(args) != 2:
        print("Usage: ping <server_ip> <server_port>")
        return

    server_ip = args[0]
    try:
        server_port = int(args[1])
    except ValueError:
        print("Please provide a valid server port (integer).")
        return

    print(f"Pinging Minecraft server at {server_ip}:{server_port}...\n")
    try:
        server = JavaServer(server_ip, server_port)  # Use JavaServer instead
        status = server.status()  # Sends a ping request to the server
        print(f"Successfully connected to {server_ip}:{server_port}!")
        print(f"Ping: {status.latency}ms")
        print(f"Server version: {status.version.name}")
        print(f"Players online: {status.players.online}/{status.players.max}")
    except Exception as e:
        print(f"Error while pinging server: {e}")
        print(f"Failed to connect to {server_ip}:{server_port}.")
