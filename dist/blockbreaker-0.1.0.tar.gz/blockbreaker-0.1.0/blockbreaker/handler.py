from blockbreaker.commands.ping import ping_command

class CommandHandler:
    """Handles the routing of commands to their respective functions."""
    def __init__(self):
        self.commands = {
            'ping': ping_command
        }

    def execute(self, command, args):
        """Executes the given command with its arguments."""
        if command in self.commands:
            self.commands[command](args)
        else:
            print(f"Unknown command: {command}")
            print("Available commands: ping")
