import readline  # Import the readline module to enable history and cursor navigation.
from blockbreaker.handler import CommandHandler

# ASCII art for the shell prompt
ascii_art = """██████╗ ██╗      ██████╗  ██████╗██╗  ██╗██████╗ ██████╗ ███████╗ █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝██║     ██║   ██║██║     █████╔╝ ██████╔╝██████╔╝█████╗  ███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██║     ██║   ██║██║     ██╔═██╗ ██╔══██╗██╔══██╗██╔══╝  ██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝███████╗╚██████╔╝╚██████╗██║  ██╗██████╔╝██║  ██║███████╗██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"""

def start_shell():
    """Start the interactive shell loop."""
    print(ascii_art)
    print("Welcome to the Minecraft Pentesting Shell. Type 'exit' to quit.")
    
    handler = CommandHandler()

    # Enable history in the shell, which allows command history using the arrow keys.
    readline.set_history_length(100)  # Set the number of commands to remember in history.
    
    while True:
        # Simulate a shell prompt
        user_input = input(">>> ").strip()  # Input will now work with arrow keys for navigation

        if user_input.lower() == "exit":
            print("Exiting Minecraft Pentesting Shell...")
            break
        
        # Split the command and its arguments
        parts = user_input.split()
        command = parts[0]
        args = parts[1:]

        # Execute the command via the handler
        handler.execute(command, args)

if __name__ == "__main__":
    start_shell()
